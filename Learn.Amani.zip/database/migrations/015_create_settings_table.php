﻿<section class="section">
    <div class="container">
        <h1 class="fw-bold text-capitalize">015_create_settings_table</h1>
        <p class="text-muted">This page is ready for custom content.</p>
        <a class="btn btn-primary" href="<?= base_url('courses'); ?>">Browse courses</a>
    </div>
</section>
