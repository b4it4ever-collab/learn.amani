﻿<section class="section">
    <div class="container">
        <h1 class="fw-bold text-capitalize">007_create_quizzes_table</h1>
        <p class="text-muted">This page is ready for custom content.</p>
        <a class="btn btn-primary" href="<?= base_url('courses'); ?>">Browse courses</a>
    </div>
</section>
