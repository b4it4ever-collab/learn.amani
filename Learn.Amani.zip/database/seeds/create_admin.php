<?php

declare(strict_types=1);

// Usage: php create_admin.php [email] [password]
// Example: php create_admin.php admin@admin123.org "Fathi2434@"

$defaultEmail = 'admin@admin123.org';
$defaultPassword = 'Fathi2434@';

$email = $argv[1] ?? $defaultEmail;
$password = $argv[2] ?? $defaultPassword;

// Try to load .env for DB settings
function loadEnv(string $path): array
{
    if (!is_file($path)) {
        return [];
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $vars = [];
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (!str_contains($line, '=')) continue;
        [$k, $v] = array_map('trim', explode('=', $line, 2));
        $vars[$k] = trim($v, "\"' ");
    }
    return $vars;
}

$env = loadEnv(__DIR__ . '/../../.env');
$host = $env['DB_HOST'] ?? '127.0.0.1';
$dbname = $env['DB_NAME'] ?? 'learn_amani';
$dbuser = $env['DB_USER'] ?? 'root';
$dbpass = $env['DB_PASS'] ?? '';

$dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $dbuser, $dbpass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Throwable $e) {
    fwrite(STDERR, "DB connection failed: " . $e->getMessage() . PHP_EOL);
    exit(2);
}

$hash = password_hash($password, PASSWORD_DEFAULT);

// Check if users table exists
try {
    $stmt = $pdo->query("SELECT 1 FROM users LIMIT 1");
} catch (Throwable $e) {
    fwrite(STDERR, "Users table not found or DB not initialized: " . $e->getMessage() . PHP_EOL);
    exit(3);
}

// Insert or update admin user
try {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email');
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    if ($user) {
        $pdo->prepare('UPDATE users SET password = :password, role = :role, status = 1 WHERE id = :id')
            ->execute(['password' => $hash, 'role' => 'admin', 'id' => $user['id']]);
        echo "Updated existing user {$email} to admin.\n";
    } else {
        $pdo->prepare('INSERT INTO users (name, email, password, role, status) VALUES (:name, :email, :password, :role, 1)')
            ->execute(['name' => 'Admin', 'email' => $email, 'password' => $hash, 'role' => 'admin']);
        echo "Inserted new admin user {$email}.\n";
    }
} catch (Throwable $e) {
    fwrite(STDERR, "DB operation failed: " . $e->getMessage() . PHP_EOL);
    exit(4);
}

echo "Done. You can now log in with {$email} and the provided password.\n";
