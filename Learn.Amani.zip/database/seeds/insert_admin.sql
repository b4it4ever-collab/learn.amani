-- Insert admin user for Learn.Amani
-- Replace <PASSWORD_HASH> with the output from the PHP command below.

INSERT INTO users (name, email, password, role, status) VALUES
('Admin', 'admin@admin123.org', '<PASSWORD_HASH>', 'admin', 1);
