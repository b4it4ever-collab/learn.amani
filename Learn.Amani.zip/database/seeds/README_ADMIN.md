Steps to create the admin user (run locally on your machine running XAMPP):

1. Generate a PHP password hash for the password `Fathi2434@`:

```bash
php -r "echo password_hash('Fathi2434@', PASSWORD_DEFAULT).PHP_EOL;"
```

Copy the resulting hash string.

2. Open `database/seeds/insert_admin.sql` and replace `<PASSWORD_HASH>` with the copied hash (include the surrounding single quotes).

3. Run the SQL using one of these methods:

- phpMyAdmin: open your database, go to SQL tab, paste the INSERT and execute.
- MySQL CLI (replace credentials as needed):

```bash
mysql -u root -p learn_amani_db < database/seeds/insert_admin.sql
```

Or paste the INSERT into a SQL query runner.

If you'd like, I can also create a PHP seeder script that reads your DB config and inserts the admin automatically — tell me if you want that and provide DB connection details or confirm where to read them from.