<?php

declare(strict_types=1);

return [
    '/' => [HomeController::class, 'index'],
    '/home' => [HomeController::class, 'index'],
    '/courses' => [CoursesController::class, 'index'],
    '/course' => [CoursesController::class, 'show'],
    '/lessons' => [LessonsController::class, 'show'],
    '/categories' => [CategoriesController::class, 'index'],
    '/instructors' => [InstructorsController::class, 'index'],
    '/about' => [AboutController::class, 'index'],
    '/contact' => [ContactController::class, 'index'],
    '/faq' => [FaqController::class, 'index'],
    '/login' => [AuthController::class, 'login'],
    '/register' => [AuthController::class, 'register'],
    '/dashboard' => [DashboardController::class, 'student'],
    '/my-courses' => [CoursesController::class, 'myCourses'],
    '/quiz' => [QuizController::class, 'index'],
    '/certificate' => [CertificateController::class, 'index'],
];
