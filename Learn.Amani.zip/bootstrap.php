<?php

declare(strict_types=1);

session_start();

spl_autoload_register(function (string $class): void {
    $folders = [
        ROOT_PATH . '/app/Models',
        ROOT_PATH . '/app/Controllers',
        ROOT_PATH . '/app/Core',
    ];

    foreach ($folders as $folder) {
        $file = $folder . '/' . $class . '.php';
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
});

require_once ROOT_PATH . '/app/Core/Helpers.php';

$routes = require ROOT_PATH . '/routes/web.php';
$router = new Router($routes);
$router->dispatch($_SERVER['REQUEST_URI'] ?? '/');
