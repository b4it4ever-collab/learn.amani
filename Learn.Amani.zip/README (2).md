# Learn.Amani
Project folder structure.
