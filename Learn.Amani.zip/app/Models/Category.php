<?php

declare(strict_types=1);

class Category extends Model
{
    public static function all(): array
    {
        return [
            ['name' => 'Development', 'icon' => 'bi-code-slash', 'courses' => 12],
            ['name' => 'Design', 'icon' => 'bi-palette', 'courses' => 8],
            ['name' => 'Marketing', 'icon' => 'bi-megaphone', 'courses' => 6],
            ['name' => 'Business', 'icon' => 'bi-briefcase', 'courses' => 9],
            ['name' => 'Languages', 'icon' => 'bi-translate', 'courses' => 7],
            ['name' => 'Life Skills', 'icon' => 'bi-stars', 'courses' => 10],
        ];
    }
}
