<?php

declare(strict_types=1);

class Course extends Model
{
    public static function all(): array
    {
        return self::courses();
    }

    public static function featured(): array
    {
        return array_slice(self::courses(), 0, 3);
    }

    public static function find(int $id): ?array
    {
        foreach (self::courses() as $course) {
            if ((int) $course['id'] === $id) {
                return $course;
            }
        }

        return null;
    }

    public static function enrolled(): array
    {
        return [
            self::courses()[0] + ['progress' => 72],
            self::courses()[1] + ['progress' => 38],
        ];
    }
}
