<?php

declare(strict_types=1);

class Model
{
    protected static function courses(): array
    {
        return [
            [
                'id' => 1,
                'title' => 'Web Development Foundations',
                'category' => 'Development',
                'level' => 'Beginner',
                'duration' => '8 weeks',
                'lessons' => 24,
                'students' => 1280,
                'price' => 'Free',
                'image' => 'images/course1.jpg',
                'description' => 'Build responsive websites with HTML, CSS, JavaScript, and PHP basics.',
            ],
            [
                'id' => 2,
                'title' => 'Graphic Design Essentials',
                'category' => 'Design',
                'level' => 'Intermediate',
                'duration' => '6 weeks',
                'lessons' => 18,
                'students' => 940,
                'price' => 'Free',
                'image' => 'images/course2.jpg',
                'description' => 'Learn layout, color, typography, branding, and portfolio-ready design projects.',
            ],
            [
                'id' => 3,
                'title' => 'Digital Marketing Strategy',
                'category' => 'Marketing',
                'level' => 'Beginner',
                'duration' => '5 weeks',
                'lessons' => 16,
                'students' => 770,
                'price' => 'Free',
                'image' => 'images/course3.jpg',
                'description' => 'Plan campaigns, grow audiences, write better content, and track results.',
            ],
        ];
    }
}
