<?php

declare(strict_types=1);

class Instructor extends Model
{
    public static function all(): array
    {
        return [
            ['name' => 'Amani Hassan', 'role' => 'Web Instructor', 'students' => 1200],
            ['name' => 'Maya Kareem', 'role' => 'Design Mentor', 'students' => 860],
            ['name' => 'Omar Saleh', 'role' => 'Marketing Coach', 'students' => 740],
        ];
    }
}
