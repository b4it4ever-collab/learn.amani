<a class="nav-link" href="/Learn.Amani/public/">Home</a>

<a class="nav-link" href="/Learn.Amani/public/courses">Courses</a>

<a class="nav-link" href="/Learn.Amani/public/categories">Categories</a>

<a class="nav-link" href="/Learn.Amani/public/about">About</a>

<a class="nav-link" href="/Learn.Amani/public/contact">Contact</a>