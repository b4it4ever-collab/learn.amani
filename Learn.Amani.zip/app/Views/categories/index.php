<section class="page-header">
    <div class="container">
        <span class="eyebrow">Learning paths</span>
        <h1>Course categories</h1>
        <p>Pick a category and follow a clear path from first lesson to certificate.</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="category-grid large">
            <?php foreach ($categories as $category): ?>
                <a class="category-tile" href="<?= base_url('courses'); ?>">
                    <i class="bi <?= e($category['icon']); ?>"></i>
                    <span><?= e($category['name']); ?></span>
                    <small><?= e((string) $category['courses']); ?> courses</small>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
