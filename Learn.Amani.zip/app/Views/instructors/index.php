<section class="page-header">
    <div class="container">
        <span class="eyebrow">Mentors</span>
        <h1>Meet the instructors</h1>
        <p>Course leaders who guide students through practical projects.</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="row g-4">
            <?php foreach ($instructors as $instructor): ?>
                <div class="col-md-4">
                    <div class="info-box text-center">
                        <img class="avatar" src="<?= asset('images/avatar.png'); ?>" alt="<?= e($instructor['name']); ?>">
                        <h3><?= e($instructor['name']); ?></h3>
                        <p><?= e($instructor['role']); ?></p>
                        <span class="text-muted"><?= e(number_format($instructor['students'])); ?> students</span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
