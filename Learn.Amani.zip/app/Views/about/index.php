<section class="page-header">
    <div class="container">
        <span class="eyebrow">About us</span>
        <h1>Learning that stays practical</h1>
        <p>Learn.Amani helps students build useful skills through structured courses, progress tracking, and simple certificates.</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4"><div class="info-box"><i class="bi bi-book"></i><h3>Structured courses</h3><p>Each course is split into lessons, practice tasks, and quizzes.</p></div></div>
            <div class="col-md-4"><div class="info-box"><i class="bi bi-person-check"></i><h3>Student progress</h3><p>Learners can see what they started, completed, and should continue next.</p></div></div>
            <div class="col-md-4"><div class="info-box"><i class="bi bi-award"></i><h3>Certificates</h3><p>Finished courses can generate certificates for student portfolios.</p></div></div>
        </div>
    </div>
</section>
