<section class="section text-center">
    <div class="container">
        <h1 class="display-4 fw-bold">404</h1>
        <p class="lead text-muted">The page you requested was not found.</p>
        <a class="btn btn-primary" href="<?= base_url(); ?>">Back home</a>
    </div>
</section>
