<section class="py-20">

<div class="container mx-auto px-6">

<h1 class="text-4xl font-bold">

Welcome

<?= Session::get('user')['name']; ?>

🎉

</h1>

<p class="mt-4 text-gray-500">

Welcome to Learn.Amani

</p>

<div class="grid md:grid-cols-3 gap-6 mt-10">

<div class="bg-white rounded-xl shadow p-8">

<h2 class="font-bold">

My Courses

</h2>

<p class="text-5xl mt-4">

0

</p>

</div>

<div class="bg-white rounded-xl shadow p-8">

<h2 class="font-bold">

Completed

</h2>

<p class="text-5xl mt-4">

0

</p>

</div>

<div class="bg-white rounded-xl shadow p-8">

<h2 class="font-bold">

Certificates

</h2>

<p class="text-5xl mt-4">

0

</p>

</div>

</div>

</div>

</section>