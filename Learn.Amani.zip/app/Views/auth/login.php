<section class="auth-section">
    <form class="auth-panel" method="post">
        <h1>Welcome back</h1>
        <p class="text-muted">Login form UI for the Learn.Amani demo.</p>
        <label>Email<input class="form-control" type="email" name="email" required></label>
        <label>Password<input class="form-control" type="password" name="password" required></label>
        <button class="btn btn-primary w-100" type="submit">Login</button>
        <p class="small text-center mb-0">No account? <a href="<?= base_url('register'); ?>">Create one</a></p>
    </form>
</section>
