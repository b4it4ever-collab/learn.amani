<section class="auth-section">
    <form class="auth-panel" method="post">
        <h1>Create account</h1>
        <p class="text-muted">Registration form UI for students.</p>
        <label>Name<input class="form-control" name="name" required></label>
        <label>Email<input class="form-control" type="email" name="email" required></label>
        <label>Password<input class="form-control" type="password" name="password" required></label>
        <button class="btn btn-primary w-100" type="submit">Join free</button>
        <p class="small text-center mb-0">Already registered? <a href="<?= base_url('login'); ?>">Login</a></p>
    </form>
</section>
