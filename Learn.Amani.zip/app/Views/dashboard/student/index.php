<section class="page-header">
    <div class="container">
        <span class="eyebrow">Student area</span>
        <h1>My dashboard</h1>
        <p>Continue your courses, check progress, and jump back into the next lesson.</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="row g-4 mb-4">
            <div class="col-md-4"><div class="stat-box"><strong>2</strong><span>Active courses</span></div></div>
            <div class="col-md-4"><div class="stat-box"><strong>31</strong><span>Lessons watched</span></div></div>
            <div class="col-md-4"><div class="stat-box"><strong>1</strong><span>Certificate earned</span></div></div>
        </div>
        <div class="row g-4">
            <?php foreach ($courses as $course): ?>
                <div class="col-lg-6">
                    <div class="progress-panel">
                        <h3><?= e($course['title']); ?></h3>
                        <p class="text-muted"><?= e($course['description']); ?></p>
                        <div class="progress mb-3" role="progressbar" aria-valuenow="<?= e((string) $course['progress']); ?>" aria-valuemin="0" aria-valuemax="100">
                            <div class="progress-bar" style="width: <?= e((string) $course['progress']); ?>%"><?= e((string) $course['progress']); ?>%</div>
                        </div>
                        <a class="btn btn-outline-primary" href="<?= base_url('lessons?course=' . $course['id']); ?>">Continue</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
