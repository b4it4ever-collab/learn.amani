<section class="page-header">
    <div class="container">
        <span class="eyebrow">Help</span>
        <h1>Frequently asked questions</h1>
        <p>Answers for students using the course platform.</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="accordion" id="faq">
            <?php foreach (['Are courses free?' => 'Yes, the demo courses are marked free.', 'Can students get certificates?' => 'Yes, certificate pages are included and ready for database connection.', 'Does login work?' => 'The forms are designed now; authentication logic can be connected next.'] as $question => $answer): ?>
                <div class="accordion-item">
                    <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q<?= md5($question); ?>"><?= e($question); ?></button></h2>
                    <div id="q<?= md5($question); ?>" class="accordion-collapse collapse" data-bs-parent="#faq"><div class="accordion-body"><?= e($answer); ?></div></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
