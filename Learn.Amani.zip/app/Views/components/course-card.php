<article class="course-card h-100">
    <img src="<?= asset($course['image']); ?>" alt="<?= e($course['title']); ?>">
    <div class="course-card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="badge text-bg-primary"><?= e($course['level']); ?></span>
            <strong><?= e($course['price']); ?></strong>
        </div>
        <h3><?= e($course['title']); ?></h3>
        <p><?= e($course['description']); ?></p>
        <div class="course-meta">
            <span><i class="bi bi-clock"></i><?= e($course['duration']); ?></span>
            <span><i class="bi bi-journal-text"></i><?= e((string) $course['lessons']); ?> lessons</span>
            <span><i class="bi bi-people"></i><?= e(number_format((int) $course['students'])); ?> students</span>
        </div>
        <a class="btn btn-outline-primary w-100 mt-3" href="<?= base_url('course?id=' . $course['id']); ?>">View course <i class="bi bi-arrow-right ms-1"></i></a>
    </div>
</article>
