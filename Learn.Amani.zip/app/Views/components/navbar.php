<nav class="navbar navbar-expand-lg site-navbar sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="<?= base_url(); ?>">
            <img src="<?= asset('images/logo.png'); ?>" alt="Learn.Amani" width="34" height="34">
            <span>Learn.Amani</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                <li class="nav-item"><a class="nav-link <?= active_link('/'); ?>" href="<?= base_url(); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link <?= active_link('/courses'); ?>" href="<?= base_url('courses'); ?>">Courses</a></li>
                <li class="nav-item"><a class="nav-link <?= active_link('/categories'); ?>" href="<?= base_url('categories'); ?>">Categories</a></li>
                <li class="nav-item"><a class="nav-link <?= active_link('/instructors'); ?>" href="<?= base_url('instructors'); ?>">Instructors</a></li>
                <li class="nav-item"><a class="nav-link <?= active_link('/about'); ?>" href="<?= base_url('about'); ?>">About</a></li>
                <li class="nav-item"><a class="btn btn-outline-primary btn-sm" href="<?= base_url('login'); ?>">Login</a></li>
                <li class="nav-item"><a class="btn btn-primary btn-sm" href="<?= base_url('register'); ?>">Join free</a></li>
            </ul>
        </div>
    </div>
</nav>
