<footer class="border-top bg-white py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <h5 class="fw-bold">Learn.Amani</h5>
                <p class="text-muted mb-0">A practical learning platform for courses, lessons, quizzes, certificates, and student progress.</p>
            </div>
            <div class="col-6 col-lg-2">
                <h6 class="fw-semibold">Learn</h6>
                <a class="footer-link" href="<?= base_url('courses'); ?>">Courses</a>
                <a class="footer-link" href="<?= base_url('categories'); ?>">Categories</a>
                <a class="footer-link" href="<?= base_url('quiz'); ?>">Quizzes</a>
            </div>
            <div class="col-6 col-lg-2">
                <h6 class="fw-semibold">Account</h6>
                <a class="footer-link" href="<?= base_url('dashboard'); ?>">Dashboard</a>
                <a class="footer-link" href="<?= base_url('my-courses'); ?>">My courses</a>
                <a class="footer-link" href="<?= base_url('certificate'); ?>">Certificates</a>
            </div>
            <div class="col-lg-3">
                <h6 class="fw-semibold">Contact</h6>
                <a class="footer-link" href="<?= base_url('contact'); ?>">Send a message</a>
                <span class="text-muted small">support@learn-amani.test</span>
            </div>
        </div>
        <div class="pt-4 mt-4 border-top text-muted small">© <?= date('Y'); ?> Learn.Amani. All rights reserved.</div>
    </div>
</footer>
