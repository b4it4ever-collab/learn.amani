<section class="py-5 bg-white" id="courses">

    <div class="container">

        <div class="text-center mb-5">

            <span class="badge bg-primary mb-3">

                Popular Courses

            </span>

            <h2 class="display-5 fw-bold">

                Featured Courses

            </h2>

            <p class="text-muted">

                Discover our most popular learning programs.

            </p>

        </div>

        <div class="row g-4">

            <?php

            $courses = [

                [
                    'title' => 'Web Development',
                    'image' => 'https://picsum.photos/600/400?1',
                    'level' => 'Beginner',
                    'price' => 'Free'
                ],

                [
                    'title' => 'Graphic Design',
                    'image' => 'https://picsum.photos/600/400?2',
                    'level' => 'Intermediate',
                    'price' => '$29'
                ],

                [
                    'title' => 'Digital Marketing',
                    'image' => 'https://picsum.photos/600/400?3',
                    'level' => 'Advanced',
                    'price' => '$49'
                ]

            ];

            foreach($courses as $course):

            ?>

            <div class="col-lg-4">

                <div class="card border-0 shadow h-100">

                    <img
                        src="<?= $course['image']; ?>"
                        class="card-img-top">

                    <div class="card-body">

                        <span class="badge bg-success">

                            <?= $course['level']; ?>

                        </span>

                        <h4 class="mt-3">

                            <?= $course['title']; ?>

                        </h4>

                        <p class="text-muted">

                            Learn practical skills with hands-on projects.

                        </p>

                    </div>

                    <div class="card-footer bg-white border-0 d-flex justify-content-between align-items-center">

                        <strong class="text-primary">

                            <?= $course['price']; ?>

                        </strong>

                        <a href="#"
                           class="btn btn-primary">

                            View Course

                        </a>

                    </div>

                </div>

            </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>