<section class="bg-white py-20">
    <div class="container mx-auto px-6">

        <div class="text-center mb-12">
            <h1 class="text-5xl font-bold text-slate-800">
                About Learn.Amani
            </h1>

            <p class="mt-6 text-lg text-slate-600 max-w-3xl mx-auto">
                Learn.Amani is a modern online learning platform designed
                to empower students with quality education, practical skills,
                and lifelong learning opportunities.
            </p>
        </div>

        <div class="grid md:grid-cols-3 gap-8">

            <div class="bg-slate-50 p-8 rounded-xl shadow">
                <h3 class="text-2xl font-bold mb-4 text-blue-600">
                    Our Mission
                </h3>

                <p class="text-slate-600">
                    To provide accessible, affordable, and engaging online
                    education for everyone.
                </p>
            </div>

            <div class="bg-slate-50 p-8 rounded-xl shadow">
                <h3 class="text-2xl font-bold mb-4 text-green-600">
                    Our Vision
                </h3>

                <p class="text-slate-600">
                    To become a trusted digital learning platform that
                    transforms lives through knowledge.
                </p>
            </div>

            <div class="bg-slate-50 p-8 rounded-xl shadow">
                <h3 class="text-2xl font-bold mb-4 text-purple-600">
                    Our Values
                </h3>

                <p class="text-slate-600">
                    Excellence, Integrity, Innovation, Community, and
                    Continuous Learning.
                </p>
            </div>

        </div>

    </div>
</section>