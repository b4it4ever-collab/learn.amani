<section class="hero-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="hero-kicker"><i class="bi bi-stars"></i> Modern learning for practical skills</span>
                <h1 class="display-4 fw-bold mb-3">Build useful skills with guided online courses</h1>
                <p class="lead text-muted mb-4">Learn.Amani helps students study focused lessons, practice with quizzes, track progress, and earn certificates from one clean learning dashboard.</p>
                <div class="d-flex flex-wrap gap-3">
                    <a class="btn btn-primary btn-lg" href="<?= base_url('courses'); ?>"><i class="bi bi-play-circle me-2"></i>Explore courses</a>
                    <a class="btn btn-outline-dark btn-lg" href="<?= base_url('dashboard'); ?>"><i class="bi bi-grid me-2"></i>Student dashboard</a>
                </div>
                <div class="hero-stats">
                    <div><strong>3</strong><span>course paths</span></div>
                    <div><strong>58</strong><span>sample lessons</span></div>
                    <div><strong>2.9k</strong><span>learners shown</span></div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-media">
                    <img class="hero-image" src="<?= asset('images/hero-image.png'); ?>" alt="Students learning online">
                    <div class="floating-card">
                        <i class="bi bi-award"></i>
                        <div>
                            <strong>Certificates ready</strong>
                            <span>After lessons and quizzes</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="info-box h-100">
                    <i class="bi bi-map"></i>
                    <h3>Guided paths</h3>
                    <p class="text-muted mb-0">Courses are organized by clear outcomes so learners know what to study next.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-box h-100">
                    <i class="bi bi-check2-circle"></i>
                    <h3>Practice and quizzes</h3>
                    <p class="text-muted mb-0">Each topic can include short checks, progress tracking, and review moments.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-box h-100">
                    <i class="bi bi-person-video3"></i>
                    <h3>Instructor profiles</h3>
                    <p class="text-muted mb-0">The platform already has pages for teachers, course details, and student dashboards.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-heading">
            <span class="eyebrow">Popular courses</span>
            <h2>Start with a guided course</h2>
        </div>
        <div class="row g-4">
            <?php foreach ($courses as $course): ?>
                <div class="col-md-6 col-lg-4">
                    <?php require ROOT_PATH . '/app/Views/components/course-card.php'; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section bg-soft">
    <div class="container">
        <div class="row g-4 align-items-center">
            <div class="col-lg-5">
                <span class="eyebrow">Categories</span>
                <h2 class="fw-bold">Choose the direction that fits your next step</h2>
                <p class="text-muted">Every category is structured around practical outcomes: watch lessons, practice, answer quizzes, and collect certificates.</p>
            </div>
            <div class="col-lg-7">
                <div class="category-grid">
                    <?php foreach (array_slice($categories, 0, 6) as $category): ?>
                        <a class="category-tile" href="<?= base_url('categories'); ?>">
                            <i class="bi <?= e($category['icon']); ?>"></i>
                            <span><?= e($category['name']); ?></span>
                            <small><?= e((string) $category['courses']); ?> courses</small>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
