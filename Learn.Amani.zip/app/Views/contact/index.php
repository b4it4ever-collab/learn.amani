<section class="page-header">
    <div class="container">
        <span class="eyebrow">Contact</span>
        <h1>Send us a message</h1>
        <p>Ask about courses, accounts, certificates, or instructor access.</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <?php if (!empty($sent)): ?><div class="alert alert-success">Thanks. Your message was received for this demo.</div><?php endif; ?>
                <form class="form-panel" method="post">
                    <label>Name<input class="form-control" name="name" required></label>
                    <label>Email<input class="form-control" type="email" name="email" required></label>
                    <label>Message<textarea class="form-control" name="message" rows="5" required></textarea></label>
                    <button class="btn btn-primary" type="submit">Send message</button>
                </form>
            </div>
        </div>
    </div>
</section>
