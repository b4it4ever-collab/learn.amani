<section class="page-header">
    <div class="container">
        <span class="eyebrow">Library</span>
        <h1>My courses</h1>
        <p>Your enrolled courses and current progress.</p>
    </div>
</section>
<section class="section">
    <div class="container">
        <div class="row g-4">
            <?php foreach ($courses as $course): ?>
                <div class="col-md-6">
                    <div class="progress-panel">
                        <h3><?= e($course['title']); ?></h3>
                        <div class="progress mb-3"><div class="progress-bar" style="width: <?= e((string) $course['progress']); ?>%"></div></div>
                        <a class="btn btn-primary" href="<?= base_url('lessons?course=' . $course['id']); ?>">Open course</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
