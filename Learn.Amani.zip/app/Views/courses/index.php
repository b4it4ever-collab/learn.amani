<section class="page-header">
    <div class="container">
        <span class="eyebrow">Course catalog</span>
        <h1>All courses</h1>
        <p>Browse the current Learn.Amani courses and start learning at your own pace.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="row g-4">
            <?php foreach ($courses as $course): ?>
                <div class="col-md-6 col-lg-4">
                    <?php require ROOT_PATH . '/app/Views/components/course-card.php'; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
