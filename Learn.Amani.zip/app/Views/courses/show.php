<section class="section">
    <div class="container">
        <div class="row g-5 align-items-start">
            <div class="col-lg-7">
                <img class="detail-image mb-4" src="<?= asset($course['image']); ?>" alt="<?= e($course['title']); ?>">
                <span class="badge text-bg-primary mb-3"><?= e($course['category']); ?></span>
                <h1 class="fw-bold"><?= e($course['title']); ?></h1>
                <p class="lead text-muted"><?= e($course['description']); ?></p>
                <h4 class="mt-5">What you will learn</h4>
                <ul class="check-list">
                    <li>Build practical projects from the first week.</li>
                    <li>Track progress through short lessons and quizzes.</li>
                    <li>Receive a certificate when the course is completed.</li>
                </ul>
            </div>
            <aside class="col-lg-5">
                <div class="side-panel">
                    <h3>Course details</h3>
                    <div class="detail-row"><span>Level</span><strong><?= e($course['level']); ?></strong></div>
                    <div class="detail-row"><span>Duration</span><strong><?= e($course['duration']); ?></strong></div>
                    <div class="detail-row"><span>Lessons</span><strong><?= e((string) $course['lessons']); ?></strong></div>
                    <div class="detail-row"><span>Students</span><strong><?= e(number_format($course['students'])); ?></strong></div>
                    <a class="btn btn-primary w-100 mt-4" href="<?= base_url('lessons?course=' . $course['id']); ?>">Start learning</a>
                </div>
            </aside>
        </div>
    </div>
</section>
