<section class="section">
    <div class="container">
        <div class="quiz-panel">
            <span class="eyebrow">Knowledge check</span>
            <h1>Quick quiz</h1>
            <p class="text-muted">Sample quiz UI. Connect this to your database later for real questions.</p>
            <form>
                <h5>What does HTML describe?</h5>
                <label class="option"><input type="radio" name="q1"> Page structure</label>
                <label class="option"><input type="radio" name="q1"> Server password</label>
                <label class="option"><input type="radio" name="q1"> Database engine</label>
                <button class="btn btn-primary mt-3" type="button">Submit answer</button>
            </form>
        </div>
    </div>
</section>
