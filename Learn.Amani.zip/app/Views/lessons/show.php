<section class="lesson-layout">
    <aside class="lesson-sidebar">
        <h5><?= e($course['title']); ?></h5>
        <a class="active" href="#">1. Introduction</a>
        <a href="#">2. Core concepts</a>
        <a href="#">3. Practice project</a>
        <a href="<?= base_url('quiz'); ?>">4. Quiz</a>
    </aside>
    <div class="lesson-content">
        <div class="video-placeholder"><i class="bi bi-play-circle"></i></div>
        <h1>Introduction lesson</h1>
        <p class="text-muted">This page is ready for your video embed, lesson text, attachments, and completion tracking.</p>
        <div class="d-flex gap-2">
            <a class="btn btn-outline-secondary" href="<?= base_url('course?id=' . $course['id']); ?>">Course details</a>
            <a class="btn btn-primary" href="<?= base_url('quiz'); ?>">Take quiz</a>
        </div>
    </div>
</section>
