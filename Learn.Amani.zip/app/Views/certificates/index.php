<section class="section">
    <div class="container">
        <div class="certificate">
            <span>Certificate of Completion</span>
            <h1>Web Development Foundations</h1>
            <p>Awarded to Student Name for completing all lessons and quizzes.</p>
            <strong>Learn.Amani</strong>
        </div>
    </div>
</section>
