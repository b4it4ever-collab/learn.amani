<?php

declare(strict_types=1);

class Router
{
    public function __construct(private array $routes)
    {
    }

    public function dispatch(string $uri): void
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $scriptBase = rtrim(str_replace('/index.php', '', str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '')), '/');

        if ($scriptBase !== '' && str_starts_with($path, $scriptBase)) {
            $path = substr($path, strlen($scriptBase)) ?: '/';
        }

        $path = '/' . trim($path, '/');
        if ($path === '//') {
            $path = '/';
        }

        [$controllerName, $method] = $this->routes[$path] ?? [HomeController::class, 'notFound'];

        if (!class_exists($controllerName) || !method_exists($controllerName, $method)) {
            http_response_code(500);
            echo 'Route target not found.';
            return;
        }

        (new $controllerName())->{$method}();
    }
}
