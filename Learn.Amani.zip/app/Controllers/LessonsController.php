<?php

declare(strict_types=1);

class LessonsController extends Controller
{
    public function show(): void
    {
        $this->view('lessons/show', [
            'title' => 'Course Lesson - Learn.Amani',
            'course' => Course::find((int) ($_GET['course'] ?? 1)) ?? Course::find(1),
        ]);
    }
}
