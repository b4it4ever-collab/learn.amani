<?php

declare(strict_types=1);

class CategoriesController extends Controller
{
    public function index(): void
    {
        $this->view('categories/index', [
            'title' => 'Categories - Learn.Amani',
            'categories' => Category::all(),
        ]);
    }
}
