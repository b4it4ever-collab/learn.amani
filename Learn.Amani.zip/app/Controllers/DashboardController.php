<?php

declare(strict_types=1);

class DashboardController extends Controller
{
    public function student(): void
    {
        $this->view('dashboard/student/index', [
            'title' => 'Student Dashboard - Learn.Amani',
            'courses' => Course::enrolled(),
        ]);
    }
}
