<?php

declare(strict_types=1);

class FaqController extends Controller
{
    public function index(): void
    {
        $this->view('faq/index', ['title' => 'FAQ - Learn.Amani']);
    }
}
