<?php

declare(strict_types=1);

class InstructorsController extends Controller
{
    public function index(): void
    {
        $this->view('instructors/index', [
            'title' => 'Instructors - Learn.Amani',
            'instructors' => Instructor::all(),
        ]);
    }
}
