<?php

declare(strict_types=1);

class ContactController extends Controller
{
    public function index(): void
    {
        $sent = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
        $this->view('contact/index', ['title' => 'Contact - Learn.Amani', 'sent' => $sent]);
    }
}
