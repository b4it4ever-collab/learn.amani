<?php

declare(strict_types=1);

class AuthController extends Controller
{
    public function login(): void
    {
        $this->view('auth/login', ['title' => 'Login - Learn.Amani']);
    }

    public function register(): void
    {
        $this->view('auth/register', ['title' => 'Create Account - Learn.Amani']);
    }
}
