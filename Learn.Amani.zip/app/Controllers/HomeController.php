<?php

declare(strict_types=1);

class HomeController extends Controller
{
    public function index(): void
    {
        $this->view('home/index', [
            'title' => 'Learn.Amani - Free Learning Courses',
            'courses' => Course::featured(),
            'categories' => Category::all(),
            'instructors' => Instructor::all(),
        ]);
    }

    public function notFound(): void
    {
        http_response_code(404);
        $this->view('errors/404', ['title' => 'Page Not Found']);
    }
}
