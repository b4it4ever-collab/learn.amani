<?php

declare(strict_types=1);

class CoursesController extends Controller
{
    public function index(): void
    {
        $this->view('courses/index', [
            'title' => 'Courses - Learn.Amani',
            'courses' => Course::all(),
        ]);
    }

    public function show(): void
    {
        $id = (int) ($_GET['id'] ?? 1);
        $course = Course::find($id) ?? Course::find(1);

        $this->view('courses/show', [
            'title' => $course['title'] . ' - Learn.Amani',
            'course' => $course,
        ]);
    }

    public function myCourses(): void
    {
        $this->view('courses/my-courses', [
            'title' => 'My Courses - Learn.Amani',
            'courses' => Course::enrolled(),
        ]);
    }
}
