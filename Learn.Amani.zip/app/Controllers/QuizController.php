<?php

declare(strict_types=1);

class QuizController extends Controller
{
    public function index(): void
    {
        $this->view('quizzes/index', ['title' => 'Quiz - Learn.Amani']);
    }
}
