<?php

declare(strict_types=1);

class CertificateController extends Controller
{
    public function index(): void
    {
        $this->view('certificates/index', ['title' => 'Certificates - Learn.Amani']);
    }
}
