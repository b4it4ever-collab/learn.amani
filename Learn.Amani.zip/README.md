# Learn.Amani

Simple PHP MVC learning-course website for XAMPP.

Suggested production subdomain: `learn.amanihome.org`.

## Pages included

- Home
- Courses
- Course details
- Lessons player
- Categories
- Instructors
- Login and register UI
- Student dashboard
- My courses
- Quiz
- Certificate
- FAQ
- Contact

## Install in XAMPP

1. Copy the `Learn.Amani_Code` folder to `C:\xampp\htdocs\Learn.Amani`.
2. Start Apache in XAMPP.
3. Open `http://localhost/Learn.Amani/public`.

The current version uses sample arrays in PHP models, so it works without a database. You can connect MySQL later by replacing the model methods with database queries.
